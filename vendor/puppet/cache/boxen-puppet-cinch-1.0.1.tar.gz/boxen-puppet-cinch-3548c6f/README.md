# Cinch Puppet Module for Boxen

[![Build Status](https://travis-ci.org/boxen/puppet-cinch.png?branch=master)](https://travis-ci.org/boxen/puppet-cinch)

Installs [Cinch](http://www.irradiatedsoftware.com/cinch).

## Usage

```puppet
include cinch
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
