# Cyberduck
[Cyberduck](http://cyberduck.ch/) FTP, SFTP, WebDAV & cloud
storage browser for Mac & Windows.

[![Build Status](https://travis-ci.org/boxen/puppet-cyberduck.png)](https://travis-ci.org/boxen/puppet-cyberduck)

## Usage

```puppet
include cyberduck
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
