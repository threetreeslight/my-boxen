# Google Japanese Input Puppet Module for Boxen

## Usage

```puppet
include google_japanese_input
```

## Required Puppet Modules

None.

## Developing

Write code.

Run `script/cibuild`.
